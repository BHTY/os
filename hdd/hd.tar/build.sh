cp ../kernel/kernel.bin kernel.bin
tar -cvf hd.tar build.sh readme.txt kernel.bin
