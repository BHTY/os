cp ../kernel/kernel.bin kernel.bin
tar -cvf hd.tar build.sh kernel.bin
