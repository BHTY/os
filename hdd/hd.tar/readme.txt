Operating System/3 Version 0.10
(c) Will Klees 2023
